---
name: Sabor Tactile Modern
colors:
  surface: '#fff8f5'
  surface-dim: '#e1d8d4'
  surface-bright: '#fff8f5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf2ed'
  surface-container: '#f5ece7'
  surface-container-high: '#efe6e2'
  surface-container-highest: '#e9e1dc'
  on-surface: '#1e1b18'
  on-surface-variant: '#594138'
  inverse-surface: '#34302c'
  inverse-on-surface: '#f8efea'
  outline: '#8d7166'
  outline-variant: '#e1bfb3'
  surface-tint: '#a53c00'
  primary: '#a13a00'
  on-primary: '#ffffff'
  primary-container: '#ca4b00'
  on-primary-container: '#fffbff'
  inverse-primary: '#ffb598'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#e2e3e2'
  on-secondary-container: '#636565'
  tertiary: '#705d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c9a904'
  on-tertiary-container: '#4c3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb598'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7e2c00'
  secondary-fixed: '#e2e3e2'
  secondary-fixed-dim: '#c6c7c6'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffe170'
  tertiary-fixed-dim: '#e7c42e'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#fff8f5'
  on-background: '#1e1b18'
  surface-variant: '#e9e1dc'
  surface-warm: '#fff8f5'
  accent-yellow: '#ffe170'
  outline-warm: '#e1bfb3'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-bold:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '700'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  xs: 4px
  base: 8px
  sm: 12px
  margin-mobile: 16px
  gutter: 20px
  md: 24px
  lg: 40px
  margin-desktop: 48px
  xl: 64px
---

## Brand & Style
The brand identity is "Gourmet-Street," blending high-end culinary photography with the approachable warmth of traditional family recipes. The design style is **Tactile Modern**, characterized by the use of subtle SVG textures (dot patterns), rich organic color palettes, and soft, diffused depth. 

The aesthetic avoids the sterile nature of pure minimalism by incorporating "delicious" visual cues: warm amber glows, soft shadows that mimic physical objects on a surface, and decorative flourishes like handwritten-style underlines. The emotional response is one of craving, comfort, and premium quality.

## Colors
The palette is rooted in the "Golden Hour" of frying. The **Primary Orange (#eb5e15)** acts as the heat and energy of the brand, used for calls to action and critical brand moments. **Tertiary Yellow (#edca34)** serves as a secondary accent, mimicking the color of perfectly fried corn dough.

The background uses a **Surface Warm (#fff8f5)** instead of pure white to maintain a cozy, parchment-like feel. Text is rendered in deep charcoals and warm browns to ensure high legibility without the harshness of pure black. Functional states use a tonal approach—primary buttons shift to a deeper container shade on hover rather than a flat gray.

## Typography
The system uses a pairing of **Plus Jakarta Sans** for structure and **Work Sans** for utility. Headlines are set with tight tracking and heavy weights (700-800) to command attention and feel "meaty" and substantial. 

Body text utilizes Work Sans for its exceptional legibility and neutral character, allowing the food photography to remain the hero. Labels and buttons use the geometric clarity of Plus Jakarta Sans to ensure navigation and actions feel modern and decisive. On mobile, the display type scales down slightly to maintain a comfortable reading rhythm while preserving the bold hierarchy.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy within a max-width of 1280px, ensuring a premium, curated feel on ultra-wide displays. A 12-column system is used for desktop, often splitting into a 6/6 or 8/4 asymmetrical balance to create visual interest.

Margins are generous—48px on desktop and 16px on mobile—providing ample "breathing room" that elevates the brand above typical fast-food layouts. Vertical spacing (XL/64px) is used between sections to clearly demarcate the narrative flow (Hero > Menu > History).

## Elevation & Depth
Depth is communicated through **Ambient Shadows** and **Tonal Layering**. Instead of stark black shadows, the system uses "Tinted Shadows"—low-opacity drops that incorporate the primary orange hue (e.g., `rgba(235, 94, 21, 0.12)`). This makes elements like buttons and cards appear as if they are resting on a warm, reflective surface.

A hierarchy of surfaces is established:
1. **Background:** Surface Warm (#fff8f5).
2. **Low Elevation:** Surface-container-low, used for large section backgrounds.
3. **High Elevation:** White containers with soft shadows, used for interactive cards and the sticky navigation bar.
4. **Interactive:** Subtle `-translate-y-1` transforms on hover to simulate physical "lift."

## Shapes
The shape language is **Rounded**, using a base radius of 0.5rem (8px). This creates a friendly, safe, and organic feel that complements the rounded nature of the food (empanadas, arepas). 

- **Standard Buttons & Cards:** 0.5rem (rounded-lg) for a modern, approachable look.
- **Featured Bento Items:** 0.75rem (rounded-xl) to emphasize their "soft" container nature.
- **Pills/Badges:** Full rounding (9999px) to distinguish them as metadata or status indicators.
- **Images:** Always clipped with 0.75rem radius to maintain the soft-tactile aesthetic.

## Components

### Buttons
Primary buttons are high-contrast orange with white text, featuring a distinctive "glow" shadow. Secondary buttons use the yellow-accent palette (#ffe170) with dark text to provide a clear hierarchy when two actions are presented together. All buttons feature a 200ms transition for hover states involving both color shifts and vertical translation.

### Cards & Bento Grid
Cards use a "borderless" approach, relying on tonal background shifts (Surface-Container) and soft shadows to define boundaries. In the "Bento" layout, images are either full-bleed within the card or occupy the top half, with text content separated by a subtle warm-tinted hairline border.

### Chips & Badges
Badges are used for "New" or "Hot" items, featuring a pill-shaped container and a combination of icons + uppercase bold labels. They often use a 20% opacity version of the primary or tertiary colors to remain visible without being distracting.

### Lists
Menu lists are minimalist, utilizing a simple horizontal rule in a low-contrast warm tint (#e1bfb3 at 30% opacity). Hovering over a list item triggers a background color change to `surface-container-low`, providing immediate feedback for interactive menu items.